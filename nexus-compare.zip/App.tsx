
import React, { useState } from 'react';
import { HashRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { BarChart2, X } from 'lucide-react';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Compare from './pages/Compare';
import ProductDetails from './pages/ProductDetails';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import Platforms from './pages/Platforms';
import About from './pages/About';
import Contact from './pages/Contact';
import AdminDashboard from './pages/AdminDashboard';
import Search from './pages/Search';
import AllProducts from './pages/AllProducts';
import Privacy from './pages/Privacy';
import ScrollToTop from './components/ScrollToTop';
import BottomNav from './components/BottomNav';
import Terms from './pages/Terms';
import NotFound from './pages/NotFound';
import { Product } from './types';

const App: React.FC = () => {
  const [compareList, setCompareList] = useState<Product[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  const toggleCompare = (product: Product) => {
    setCompareList(prev => {
      const exists = prev.find(p => p.id === product.id);
      if (exists) {
        return prev.filter(p => p.id !== product.id);
      }
      if (prev.length >= 4) {
        alert("Maximum 4 items for comparison.");
        return prev;
      }
      return [...prev, product];
    });
  };

  const removeCompare = (id: string) => {
    setCompareList(prev => prev.filter(p => p.id !== id));
  };

  const clearCompare = () => setCompareList([]);

  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen flex flex-col pb-20 lg:pb-0">
        <Navbar onSearch={(q) => {
          setSearchQuery(q);
          window.location.hash = `#/search?q=${q}`;
        }} />
        
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home onAddToCompare={toggleCompare} compareList={compareList} searchQuery={searchQuery} />} />
            <Route path="/search" element={<Search onAddToCompare={toggleCompare} compareList={compareList} />} />
            <Route path="/all-products" element={<AllProducts onAddToCompare={toggleCompare} compareList={compareList} />} />
            <Route path="/compare" element={<Compare compareList={compareList} onRemove={removeCompare} onClear={clearCompare} />} />
            <Route path="/product/:id" element={<ProductDetails />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/platforms" element={<Platforms />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>

        {/* Floating Compare Bar */}
        {compareList.length > 0 && (
          <div className="fixed bottom-8 left-1/2 -translate-x-1/2 w-[95%] max-w-5xl bg-zinc-900 text-white p-6 z-40 shadow-2xl rounded-2xl animate-in slide-in-from-bottom duration-500 border border-white/10">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-6">
                <div className="hidden sm:flex items-center -space-x-3">
                  {compareList.map(p => (
                    <div key={p.id} className="w-10 h-14 border-2 border-zinc-800 shadow-lg relative group overflow-hidden rounded-md">
                      <img src={p.image} className="w-full h-full object-cover" alt={p.name} />
                      <button 
                        onClick={() => removeCompare(p.id)}
                        className="absolute inset-0 bg-black/60 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-white">{compareList.length} Items Selected</p>
                  <p className="text-[9px] text-zinc-500 uppercase tracking-widest hidden sm:block">Ready for side-by-side analysis</p>
                </div>
              </div>
              <div className="flex items-center space-x-8">
                <button 
                  onClick={clearCompare}
                  className="text-[10px] uppercase tracking-widest font-bold text-zinc-500 hover:text-white transition-colors"
                >
                  Clear
                </button>
                <Link 
                  to="/compare" 
                  className="bg-white text-black px-8 py-3 text-[10px] uppercase tracking-widest font-bold flex items-center hover:bg-zinc-200 transition-all rounded-lg"
                >
                  Compare <BarChart2 size={14} className="ml-2" />
                </Link>
              </div>
            </div>
          </div>
        )}

        {/* Global Footer */}
        <footer className="bg-black text-white py-24 px-6 mt-auto">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-16">
              <div className="col-span-1 md:col-span-1">
                <Link to="/" className="text-3xl font-serif tracking-[0.2em] text-white">NEXUS</Link>
                <p className="mt-8 text-sm text-zinc-500 leading-relaxed max-w-xs">
                  India's premium fashion price comparison platform. Find the best deals across all major fashion platforms.
                </p>
                <div className="flex space-x-6 mt-8">
                  <a href="#" className="text-sm text-zinc-500 hover:text-white transition-colors">Instagram</a>
                  <a href="#" className="text-sm text-zinc-500 hover:text-white transition-colors">Twitter</a>
                  <a href="#" className="text-sm text-zinc-500 hover:text-white transition-colors">LinkedIn</a>
                </div>
              </div>
              <div>
                <h4 className="text-[10px] uppercase tracking-[0.4em] font-bold text-zinc-500 mb-8">Platform</h4>
                <ul className="space-y-4">
                  <li><Link to="/compare" className="text-sm text-zinc-400 hover:text-white transition-colors">Compare</Link></li>
                  <li><Link to="/platforms" className="text-sm text-zinc-400 hover:text-white transition-colors">Platforms</Link></li>
                  <li><Link to="/search" className="text-sm text-zinc-400 hover:text-white transition-colors">Search</Link></li>
                  <li><Link to="/dashboard" className="text-sm text-zinc-400 hover:text-white transition-colors">Dashboard</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="text-[10px] uppercase tracking-[0.4em] font-bold text-zinc-500 mb-8">Company</h4>
                <ul className="space-y-4">
                  <li><Link to="/about" className="text-sm text-zinc-400 hover:text-white transition-colors">About</Link></li>
                  <li><Link to="/contact" className="text-sm text-zinc-400 hover:text-white transition-colors">Contact</Link></li>
                  <li><Link to="/privacy" className="text-sm text-zinc-400 hover:text-white transition-colors">Privacy Policy</Link></li>
                  <li><Link to="/terms" className="text-sm text-zinc-400 hover:text-white transition-colors">Terms of Service</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="text-[10px] uppercase tracking-[0.4em] font-bold text-zinc-500 mb-8">Account</h4>
                <ul className="space-y-4">
                  <li><Link to="/login" className="text-sm text-zinc-400 hover:text-white transition-colors">Login</Link></li>
                  <li><Link to="/signup" className="text-sm text-zinc-400 hover:text-white transition-colors">Sign Up</Link></li>
                  <li><Link to="/dashboard" className="text-sm text-zinc-400 hover:text-white transition-colors">Dashboard</Link></li>
                  <li><Link to="/admin" className="text-sm text-zinc-400 hover:text-white transition-colors">Admin</Link></li>
                </ul>
              </div>
            </div>
            <div className="mt-24 pt-8 border-t border-white/10">
              <p className="text-[10px] text-zinc-600 uppercase tracking-widest">
                © 2024 NEXUS. All rights reserved. Not affiliated with Myntra, Ajio, Flipkart or Amazon.
              </p>
            </div>
          </div>
        </footer>
        <BottomNav />
      </div>
    </Router>
  );
};

export default App;
