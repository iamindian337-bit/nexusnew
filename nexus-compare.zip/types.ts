
export interface PlatformPrice {
  platform: 'Myntra' | 'Ajio' | 'Flipkart' | 'Amazon';
  price: number;
  url: string;
}

export interface Product {
  id: string;
  name: string;
  brand: string;
  category: string;
  description: string;
  basePrice: number;
  image: string;
  gallery: string[];
  prices: PlatformPrice[];
  isFeatured?: boolean;
  gender: 'Men' | 'Women' | 'Unisex';
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  favorites: string[]; // Product IDs
  history: string[]; // Recently viewed product IDs
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
}
