
import { GoogleGenAI, Type } from "@google/genai";
import { Product } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getShoppingInsight = async (product: Product): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analyze this fashion product and give a very brief "Pro's Buy" tip for a luxury shopper.
      Product: ${product.name}
      Brand: ${product.brand}
      Category: ${product.category}
      Base Price: ₹${product.basePrice}
      Description: ${product.description}`,
      config: {
        systemInstruction: "You are an elite fashion consultant for NEXUS, a luxury fashion comparison app. Keep tips under 30 words. Focus on value, trend, and quality.",
        temperature: 0.7,
      }
    });
    return response.text || "Exclusive quality at a competitive price point.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Expertly curated for the modern wardrobe.";
  }
};
