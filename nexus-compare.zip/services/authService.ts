
import { User, AuthState } from '../types';

const MOCK_USER: User = {
  id: 'u1',
  name: 'Alex Rivera',
  email: 'alex@example.com',
  role: 'user',
  favorites: ['1', '3'],
  history: ['2', '4']
};

export const authService = {
  login: async (email: string, password: string): Promise<AuthState> => {
    // Simulated delay
    await new Promise(r => setTimeout(r, 800));
    const user = { ...MOCK_USER, email };
    localStorage.setItem('nexus_token', 'mock_jwt_token_123');
    localStorage.setItem('nexus_user', JSON.stringify(user));
    return { user, token: 'mock_jwt_token_123', isAuthenticated: true };
  },
  
  signup: async (name: string, email: string, password: string): Promise<AuthState> => {
    await new Promise(r => setTimeout(r, 1000));
    const user: User = { ...MOCK_USER, name, email };
    localStorage.setItem('nexus_token', 'mock_jwt_token_123');
    localStorage.setItem('nexus_user', JSON.stringify(user));
    return { user, token: 'mock_jwt_token_123', isAuthenticated: true };
  },

  logout: () => {
    localStorage.removeItem('nexus_token');
    localStorage.removeItem('nexus_user');
  },

  getCurrentUser: (): AuthState => {
    const token = localStorage.getItem('nexus_token');
    const userStr = localStorage.getItem('nexus_user');
    if (token && userStr) {
      return { user: JSON.parse(userStr), token, isAuthenticated: true };
    }
    return { user: null, token: null, isAuthenticated: false };
  }
};
