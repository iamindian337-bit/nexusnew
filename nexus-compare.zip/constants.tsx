
import { Product } from './types';

export const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Oversized Premium Cotton T-Shirt',
    brand: 'Nexus Essence',
    category: 'Topwear',
    gender: 'Unisex',
    description: 'A premium heavy-knit cotton t-shirt designed for ultimate comfort and a modern silhouette. Perfect for layering or wearing solo.',
    basePrice: 999,
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800',
    gallery: [
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800',
      'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=800'
    ],
    prices: [
      { platform: 'Myntra', price: 999, url: 'https://www.myntra.com' },
      { platform: 'Ajio', price: 1099, url: 'https://www.ajio.com' },
      { platform: 'Flipkart', price: 949, url: 'https://www.flipkart.com' },
      { platform: 'Amazon', price: 1049, url: 'https://www.amazon.in' }
    ],
    isFeatured: true
  },
  {
    id: '2',
    name: 'Minimalist Tech Hoodie',
    brand: 'Urban Aura',
    category: 'Hoodies',
    gender: 'Men',
    description: 'Sleek, water-resistant tech hoodie featuring a minimalist design and hidden pockets. Engineered for the modern commuter.',
    basePrice: 1999,
    image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=800',
    gallery: [
      'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=800',
      'https://images.unsplash.com/photo-1511105612320-2e62a04dd044?w=800'
    ],
    prices: [
      { platform: 'Myntra', price: 1999, url: 'https://www.myntra.com' },
      { platform: 'Ajio', price: 1899, url: 'https://www.ajio.com' },
      { platform: 'Flipkart', price: 1949, url: 'https://www.flipkart.com' },
      { platform: 'Amazon', price: 1999, url: 'https://www.amazon.in' }
    ],
    isFeatured: true
  },
  {
    id: '3',
    name: 'Architectural Leather Jacket',
    brand: 'Nexus Black',
    category: 'Outerwear',
    gender: 'Men',
    description: 'Hand-stitched Italian leather jacket with structured shoulders and a tapered waist. A timeless investment piece.',
    basePrice: 2999,
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800',
    gallery: [
      'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800'
    ],
    prices: [
      { platform: 'Myntra', price: 2999, url: 'https://www.myntra.com' },
      { platform: 'Ajio', price: 3199, url: 'https://www.ajio.com' },
      { platform: 'Flipkart', price: 2899, url: 'https://www.flipkart.com' },
      { platform: 'Amazon', price: 2999, url: 'https://www.amazon.in' }
    ],
    isFeatured: true
  },
  {
    id: '4',
    name: 'Infinite Cargo Trousers',
    brand: 'Nomad Wear',
    category: 'Trousers',
    gender: 'Men',
    description: 'Versatile cargo pants with 8 functional pockets and adjustable ankle straps. Crafted from durable ripstop nylon.',
    basePrice: 2499,
    image: 'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=800',
    gallery: [
      'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=800'
    ],
    prices: [
      { platform: 'Myntra', price: 2499, url: 'https://www.myntra.com' },
      { platform: 'Ajio', price: 2399, url: 'https://www.ajio.com' },
      { platform: 'Flipkart', price: 2449, url: 'https://www.flipkart.com' },
      { platform: 'Amazon', price: 2499, url: 'https://www.amazon.in' }
    ],
    isFeatured: true
  },
  {
    id: 's1',
    name: 'Air Max Pulse',
    brand: 'Nike',
    category: 'Sneakers',
    gender: 'Men',
    description: 'Iconic cushioning meets modern design. The Air Max Pulse brings a street-ready look to your rotation.',
    basePrice: 12995,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800',
    gallery: ['https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800'],
    prices: [
      { platform: 'Myntra', price: 12995, url: 'https://www.myntra.com' },
      { platform: 'Ajio', price: 11999, url: 'https://www.ajio.com' },
      { platform: 'Flipkart', price: 12499, url: 'https://www.flipkart.com' },
      { platform: 'Amazon', price: 12995, url: 'https://www.amazon.in' }
    ]
  },
  {
    id: 'k1',
    name: 'Embroidered Silk Kurta',
    brand: 'Fabindia',
    category: 'Kurta',
    gender: 'Men',
    description: 'Elegant silk kurta with intricate hand embroidery on the neck and cuffs. Perfect for festive occasions.',
    basePrice: 4500,
    image: 'https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=800',
    gallery: ['https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=800'],
    prices: [
      { platform: 'Myntra', price: 4500, url: 'https://www.myntra.com' },
      { platform: 'Ajio', price: 4200, url: 'https://www.ajio.com' },
      { platform: 'Flipkart', price: 4350, url: 'https://www.flipkart.com' },
      { platform: 'Amazon', price: 4500, url: 'https://www.amazon.in' }
    ]
  },
  {
    id: 'd1',
    name: 'Floral Summer Midi Dress',
    brand: 'Zara',
    category: 'Dresses',
    gender: 'Women',
    description: 'Lightweight floral print dress with a cinched waist and flowing skirt. Ideal for sunny afternoons.',
    basePrice: 3990,
    image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=800',
    gallery: ['https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=800'],
    prices: [
      { platform: 'Myntra', price: 3990, url: 'https://www.myntra.com' },
      { platform: 'Ajio', price: 3790, url: 'https://www.ajio.com' },
      { platform: 'Flipkart', price: 3850, url: 'https://www.flipkart.com' },
      { platform: 'Amazon', price: 3990, url: 'https://www.amazon.in' }
    ]
  },
  {
    id: 'hd1',
    name: 'Minimalist Ceramic Vase',
    brand: 'Home Soul',
    category: 'Home Decor',
    gender: 'Unisex',
    description: 'Matte finish ceramic vase with a unique geometric shape. Adds a touch of modern elegance to any room.',
    basePrice: 1200,
    image: 'https://images.unsplash.com/photo-1581783898377-1c85bf937427?w=800',
    gallery: ['https://images.unsplash.com/photo-1581783898377-1c85bf937427?w=800'],
    prices: [
      { platform: 'Myntra', price: 1200, url: 'https://www.myntra.com' },
      { platform: 'Ajio', price: 1100, url: 'https://www.ajio.com' },
      { platform: 'Flipkart', price: 1150, url: 'https://www.flipkart.com' },
      { platform: 'Amazon', price: 1200, url: 'https://www.amazon.in' }
    ]
  },
  {
    id: 'b1',
    name: 'Hydrating Face Serum',
    brand: 'Glow Lab',
    category: 'Beauty',
    gender: 'Unisex',
    description: 'Advanced hydration serum with hyaluronic acid and vitamin B5 for plump, glowing skin.',
    basePrice: 850,
    image: 'https://images.unsplash.com/photo-1570172619380-2126ad04840b?w=800',
    gallery: ['https://images.unsplash.com/photo-1570172619380-2126ad04840b?w=800'],
    prices: [
      { platform: 'Myntra', price: 850, url: 'https://www.myntra.com' },
      { platform: 'Ajio', price: 800, url: 'https://www.ajio.com' },
      { platform: 'Flipkart', price: 825, url: 'https://www.flipkart.com' },
      { platform: 'Amazon', price: 850, url: 'https://www.amazon.in' }
    ]
  },
  {
    id: 'a1',
    name: 'Classic Leather Watch',
    brand: 'Timeless',
    category: 'Accessories',
    gender: 'Unisex',
    description: 'Minimalist watch with a genuine leather strap and stainless steel case. A versatile accessory for any outfit.',
    basePrice: 5500,
    image: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=800',
    gallery: ['https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=800'],
    prices: [
      { platform: 'Myntra', price: 5500, url: 'https://www.myntra.com' },
      { platform: 'Ajio', price: 5200, url: 'https://www.ajio.com' },
      { platform: 'Flipkart', price: 5350, url: 'https://www.flipkart.com' },
      { platform: 'Amazon', price: 5500, url: 'https://www.amazon.in' }
    ]
  },
  {
    id: 'g1',
    name: 'Organic Quinoa',
    brand: 'Nature First',
    category: 'Grocery',
    gender: 'Unisex',
    description: 'Premium quality organic white quinoa, rich in protein and fiber. A healthy addition to your meals.',
    basePrice: 450,
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800',
    gallery: ['https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800'],
    prices: [
      { platform: 'Myntra', price: 450, url: 'https://www.myntra.com' },
      { platform: 'Ajio', price: 425, url: 'https://www.ajio.com' },
      { platform: 'Flipkart', price: 440, url: 'https://www.flipkart.com' },
      { platform: 'Amazon', price: 450, url: 'https://www.amazon.in' }
    ]
  },
  {
    id: 'j1',
    name: 'Slim Fit Blue Jeans',
    brand: 'Levis',
    category: 'Jeans',
    gender: 'Men',
    description: 'Classic slim fit jeans in a versatile blue wash. Durable and stylish.',
    basePrice: 2999,
    image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800',
    gallery: ['https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800'],
    prices: [
      { platform: 'Myntra', price: 2999, url: 'https://www.myntra.com' },
      { platform: 'Ajio', price: 2799, url: 'https://www.ajio.com' },
      { platform: 'Flipkart', price: 2899, url: 'https://www.flipkart.com' },
      { platform: 'Amazon', price: 2999, url: 'https://www.amazon.in' }
    ]
  },
  {
    id: 'w1',
    name: 'Silk Anarkali Suit',
    brand: 'Biba',
    category: 'Ethnic Wear',
    gender: 'Women',
    description: 'Beautifully crafted silk anarkali suit with heavy dupatta. Perfect for weddings.',
    basePrice: 8999,
    image: 'https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=800',
    gallery: ['https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=800'],
    prices: [
      { platform: 'Myntra', price: 8999, url: 'https://www.myntra.com' },
      { platform: 'Ajio', price: 8500, url: 'https://www.ajio.com' },
      { platform: 'Flipkart', price: 8700, url: 'https://www.flipkart.com' },
      { platform: 'Amazon', price: 8999, url: 'https://www.amazon.in' }
    ]
  },
  {
    id: 'w2',
    name: 'High-Rise Skinny Jeans',
    brand: 'Only',
    category: 'Jeans',
    gender: 'Women',
    description: 'Comfortable high-rise skinny jeans with a perfect stretch fit.',
    basePrice: 2499,
    image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800',
    gallery: ['https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800'],
    prices: [
      { platform: 'Myntra', price: 2499, url: 'https://www.myntra.com' },
      { platform: 'Ajio', price: 2299, url: 'https://www.ajio.com' },
      { platform: 'Flipkart', price: 2399, url: 'https://www.flipkart.com' },
      { platform: 'Amazon', price: 2499, url: 'https://www.amazon.in' }
    ]
  },
  {
    id: 'w3',
    name: 'Leather Crossbody Bag',
    brand: 'Mango',
    category: 'Accessories',
    gender: 'Women',
    description: 'Chic leather crossbody bag with gold-tone hardware.',
    basePrice: 3500,
    image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800',
    gallery: ['https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800'],
    prices: [
      { platform: 'Myntra', price: 3500, url: 'https://www.myntra.com' },
      { platform: 'Ajio', price: 3200, url: 'https://www.ajio.com' },
      { platform: 'Flipkart', price: 3350, url: 'https://www.flipkart.com' },
      { platform: 'Amazon', price: 3500, url: 'https://www.amazon.in' }
    ]
  }
];
