
import React, { useState } from 'react';
import { Search, User as UserIcon, ShoppingBag, Menu, X, BarChart2, ChevronLeft } from 'lucide-react';
import { useLocation, Link, useNavigate } from 'react-router-dom';
import { authService } from '../services/authService';

const Navbar: React.FC<{ onSearch: (query: string) => void }> = ({ onSearch }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const location = useLocation();
  const navigate = useNavigate();
  const auth = authService.getCurrentUser();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onSearch(searchQuery);
      navigate(`/search?q=${searchQuery}`);
    }
  };

  return (
    <nav className="fixed top-0 left-0 w-full bg-white lg:bg-white/80 lg:backdrop-blur-md z-50 border-b border-zinc-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-20 flex items-center justify-between">
        {/* Mobile Back Button */}
        {location.pathname !== '/' && (
          <button 
            onClick={() => navigate(-1)}
            className="lg:hidden p-2 -ml-2 text-zinc-600 hover:text-black transition-colors"
          >
            <ChevronLeft size={24} />
          </button>
        )}

        {/* Logo */}
        <Link to="/" className={`text-2xl sm:text-3xl font-serif tracking-[0.2em] cursor-pointer ${location.pathname !== '/' ? 'lg:block' : ''}`}>
          NEXUS
        </Link>

        {/* Desktop Links */}
        <div className="hidden lg:flex items-center space-x-10 text-sm font-medium text-zinc-600">
          <Link to="/" className={`hover:text-black transition-all pb-1 ${location.pathname === '/' ? 'text-black border-b-2 border-black' : ''}`}>Home</Link>
          <Link to="/all-products" className={`hover:text-black transition-all pb-1 ${location.pathname === '/all-products' ? 'text-black border-b-2 border-black' : ''}`}>Shop All</Link>
          <Link to="/compare" className={`hover:text-black transition-all pb-1 ${location.pathname === '/compare' ? 'text-black border-b-2 border-black' : ''}`}>Compare</Link>
          <Link to="/platforms" className={`hover:text-black transition-all pb-1 ${location.pathname === '/platforms' ? 'text-black border-b-2 border-black' : ''}`}>Platforms</Link>
          <Link to="/about" className={`hover:text-black transition-all pb-1 ${location.pathname === '/about' ? 'text-black border-b-2 border-black' : ''}`}>About</Link>
        </div>

        {/* Search & Actions */}
        <div className="flex items-center space-x-3 sm:space-x-8">
          <button 
            onClick={() => navigate('/search')}
            className="text-zinc-600 hover:text-black transition-colors p-2"
          >
            <Search size={20} />
          </button>
          
          <Link to="/login" className="hidden sm:block text-sm font-medium text-zinc-600 hover:text-black transition-colors">
            Login
          </Link>

          <Link 
            to="/signup" 
            className="hidden sm:block bg-black text-white px-6 py-2.5 text-sm font-bold hover:bg-zinc-800 transition-all"
          >
            Join Free
          </Link>

          <button 
            className="lg:hidden p-2 hover:bg-zinc-100 rounded-full transition-all"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="lg:hidden fixed inset-0 top-20 bg-white z-40 p-8 overflow-y-auto flex flex-col space-y-8 animate-in slide-in-from-top duration-300">
          <div className="flex flex-col space-y-4">
            <p className="text-[10px] uppercase tracking-[0.4em] text-zinc-400 font-bold mb-2">Main Menu</p>
            <Link to="/" className="text-xl font-serif tracking-widest border-b border-zinc-100 pb-2" onClick={() => setIsMenuOpen(false)}>Home</Link>
            <Link to="/all-products" className="text-xl font-serif tracking-widest border-b border-zinc-100 pb-2" onClick={() => setIsMenuOpen(false)}>Shop All</Link>
            <Link to="/compare" className="text-xl font-serif tracking-widest border-b border-zinc-100 pb-2" onClick={() => setIsMenuOpen(false)}>Compare</Link>
            <Link to="/platforms" className="text-xl font-serif tracking-widest border-b border-zinc-100 pb-2" onClick={() => setIsMenuOpen(false)}>Platforms</Link>
            <Link to="/about" className="text-xl font-serif tracking-widest border-b border-zinc-100 pb-2" onClick={() => setIsMenuOpen(false)}>About</Link>
          </div>

          <div className="flex flex-col space-y-4">
            <p className="text-[10px] uppercase tracking-[0.4em] text-zinc-400 font-bold mb-2">Categories</p>
            <div className="grid grid-cols-2 gap-4">
              {['Sneakers', 'Kurta', 'Jeans', 'Dresses', 'Hoodies', 'Beauty', 'Grocery', 'Home Decor'].map(cat => (
                <Link 
                  key={cat} 
                  to={`/search?q=${cat}`} 
                  className="text-sm font-medium text-zinc-600 hover:text-black"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {cat}
                </Link>
              ))}
            </div>
          </div>

          <div className="pt-4 flex flex-col space-y-4">
            <Link to="/login" className="w-full py-4 text-center border border-black font-bold uppercase tracking-widest text-sm" onClick={() => setIsMenuOpen(false)}>Login</Link>
            <Link to="/signup" className="w-full py-4 text-center bg-black text-white font-bold uppercase tracking-widest text-sm" onClick={() => setIsMenuOpen(false)}>Join Nexus</Link>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
