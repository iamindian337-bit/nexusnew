
import React from 'react';
import { Heart, Plus, BarChart2 } from 'lucide-react';
import { Product } from '../types';
import { Link } from 'react-router-dom';

interface ProductCardProps {
  product: Product;
  onAddToCompare: (p: Product) => void;
  isInCompare: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCompare, isInCompare }) => {
  return (
    <div className="group relative flex flex-col">
      <div className="relative aspect-[3/4] overflow-hidden bg-zinc-100">
        <Link to={`/product/${product.id}`}>
          <img
            src={product.image}
            alt={product.name}
            className="h-full w-full object-cover object-center transition-transform duration-700 group-hover:scale-110"
          />
        </Link>
        <div className="absolute top-4 right-4 flex flex-col space-y-2 opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <button className="p-2 sm:p-3 bg-white hover:bg-zinc-900 hover:text-white transition-all shadow-lg rounded-full">
            <Heart size={16} />
          </button>
          <button 
            onClick={() => onAddToCompare(product)}
            className={`p-2 sm:p-3 transition-all shadow-lg rounded-full ${isInCompare ? 'bg-black text-white' : 'bg-white hover:bg-zinc-900 hover:text-white'}`}
          >
            <BarChart2 size={16} />
          </button>
        </div>
        {product.isFeatured && (
          <div className="absolute bottom-4 left-4">
            <span className="bg-white px-3 py-1 text-[10px] uppercase tracking-widest font-semibold shadow-sm">
              Featured
            </span>
          </div>
        )}
      </div>

      <div className="mt-4 flex flex-col items-start">
        <div className="flex items-center space-x-2">
          <span className="text-[10px] uppercase tracking-[0.2em] text-zinc-400 font-medium">
            {product.brand}
          </span>
          <span className="text-[8px] uppercase tracking-widest bg-zinc-100 px-1.5 py-0.5 text-zinc-500 rounded">
            {product.gender}
          </span>
        </div>
        <Link to={`/product/${product.id}`} className="mt-1 text-sm font-medium hover:underline line-clamp-1">
          {product.name}
        </Link>
        <div className="mt-1 flex items-center space-x-2">
          <span className="text-sm font-semibold">₹{product.basePrice}</span>
          <span className="text-[10px] text-zinc-400 line-through">₹{Math.round(product.basePrice * 1.2)}</span>
        </div>
      </div>

      <button 
        onClick={() => onAddToCompare(product)}
        className="mt-4 w-full py-3 border border-black text-[11px] uppercase tracking-widest font-semibold hover:bg-black hover:text-white transition-all duration-300"
      >
        {isInCompare ? 'Remove from Compare' : 'Add to Compare'}
      </button>
    </div>
  );
};

export default ProductCard;
