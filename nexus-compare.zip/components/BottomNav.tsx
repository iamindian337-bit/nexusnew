
import React from 'react';
import { Home, Search, BarChart2, User, ShoppingBag } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const BottomNav: React.FC = () => {
  const location = useLocation();
  
  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="lg:hidden fixed bottom-0 left-0 w-full bg-white border-t border-zinc-100 px-6 py-3 flex items-center justify-between z-50 pb-safe">
      <Link to="/" className={`flex flex-col items-center space-y-1 ${isActive('/') ? 'text-black' : 'text-zinc-400'}`}>
        <Home size={20} />
        <span className="text-[10px] font-medium uppercase tracking-tighter">Home</span>
      </Link>
      <Link to="/search" className={`flex flex-col items-center space-y-1 ${isActive('/search') ? 'text-black' : 'text-zinc-400'}`}>
        <Search size={20} />
        <span className="text-[10px] font-medium uppercase tracking-tighter">Search</span>
      </Link>
      <Link to="/all-products" className={`flex flex-col items-center space-y-1 ${isActive('/all-products') ? 'text-black' : 'text-zinc-400'}`}>
        <ShoppingBag size={20} />
        <span className="text-[10px] font-medium uppercase tracking-tighter">Shop</span>
      </Link>
      <Link to="/compare" className={`flex flex-col items-center space-y-1 ${isActive('/compare') ? 'text-black' : 'text-zinc-400'}`}>
        <BarChart2 size={20} />
        <span className="text-[10px] font-medium uppercase tracking-tighter">Compare</span>
      </Link>
      <Link to="/login" className={`flex flex-col items-center space-y-1 ${isActive('/login') ? 'text-black' : 'text-zinc-400'}`}>
        <User size={20} />
        <span className="text-[10px] font-medium uppercase tracking-tighter">Account</span>
      </Link>
    </div>
  );
};

export default BottomNav;
