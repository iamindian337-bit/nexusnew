
import React, { useState, useMemo } from 'react';
import { MOCK_PRODUCTS } from '../constants';
import ProductCard from '../components/ProductCard';
import { SlidersHorizontal, X } from 'lucide-react';
import { Product } from '../types';

const AllProducts: React.FC<{ onAddToCompare: (p: Product) => void; compareList: Product[] }> = ({ onAddToCompare, compareList }) => {
  const [filters, setFilters] = useState({
    gender: [] as string[],
    category: [] as string[],
    platform: [] as string[],
    priceRange: 20000,
  });

  const [pendingFilters, setPendingFilters] = useState(filters);
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  const categories = ['Jeans', 'Sneakers', 'Dresses', 'Hoodies', 'Kurta', 'Trousers', 'Topwear', 'Outerwear', 'Home Decor', 'Beauty', 'Accessories', 'Grocery'];
  const genders = ['Men', 'Women', 'Unisex'];
  const platforms = ['Myntra', 'Ajio', 'Flipkart', 'Amazon'];

  const filteredProducts = useMemo(() => {
    return MOCK_PRODUCTS.filter(product => {
      const genderMatch = filters.gender.length === 0 || filters.gender.includes(product.gender);
      const categoryMatch = filters.category.length === 0 || filters.category.includes(product.category);
      const priceMatch = product.basePrice <= filters.priceRange;
      const platformMatch = filters.platform.length === 0 || product.prices.some(p => filters.platform.includes(p.platform));
      
      return genderMatch && categoryMatch && priceMatch && platformMatch;
    });
  }, [filters]);

  const togglePendingFilter = (type: 'gender' | 'category' | 'platform', value: string) => {
    setPendingFilters(prev => ({
      ...prev,
      [type]: prev[type].includes(value)
        ? prev[type].filter(v => v !== value)
        : [...prev[type], value]
    }));
  };

  const applyFilters = () => {
    setFilters(pendingFilters);
    setIsFilterOpen(false);
  };

  const clearFilters = () => {
    const cleared = {
      gender: [],
      category: [],
      platform: [],
      priceRange: 20000,
    };
    setPendingFilters(cleared);
    setFilters(cleared);
  };

  return (
    <div className="pt-32 pb-24 max-w-7xl mx-auto px-4 sm:px-6 page-enter">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-8">
        <div>
          <span className="text-[10px] uppercase tracking-[0.4em] font-bold text-zinc-400 mb-2 block">Curated Collection</span>
          <h1 className="text-4xl font-light tracking-tight">All Products</h1>
          <p className="text-zinc-500 text-sm mt-2">{filteredProducts.length} premium pieces available.</p>
        </div>
        <button 
          onClick={() => {
            if (!isFilterOpen) setPendingFilters(filters);
            setIsFilterOpen(!isFilterOpen);
          }}
          className="flex items-center justify-center space-x-3 w-full md:w-auto px-8 py-3 border border-zinc-200 text-[10px] uppercase tracking-widest font-bold hover:bg-black hover:text-white transition-all"
        >
          <SlidersHorizontal size={14} /> <span>{isFilterOpen ? 'Close Filters' : 'Refine Selection'}</span>
        </button>
      </div>

      {isFilterOpen && (
        <div className="mb-12 p-8 bg-zinc-50 rounded-2xl border border-zinc-100 animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {/* Gender Filter */}
            <div>
              <h4 className="text-[10px] uppercase tracking-widest font-bold text-zinc-400 mb-6">Gender</h4>
              <div className="space-y-3">
                {genders.map(gender => (
                  <label key={gender} className="flex items-center group cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="hidden" 
                      checked={pendingFilters.gender.includes(gender)}
                      onChange={() => togglePendingFilter('gender', gender)}
                    />
                    <div className={`w-4 h-4 border border-zinc-300 mr-3 flex items-center justify-center transition-all ${pendingFilters.gender.includes(gender) ? 'bg-black border-black' : 'group-hover:border-black'}`}>
                      {pendingFilters.gender.includes(gender) && <div className="w-1.5 h-1.5 bg-white" />}
                    </div>
                    <span className={`text-sm transition-colors ${pendingFilters.gender.includes(gender) ? 'text-black font-medium' : 'text-zinc-500 group-hover:text-black'}`}>{gender}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Category Filter */}
            <div>
              <h4 className="text-[10px] uppercase tracking-widest font-bold text-zinc-400 mb-6">Category</h4>
              <div className="grid grid-cols-2 gap-3">
                {categories.map(category => (
                  <label key={category} className="flex items-center group cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="hidden" 
                      checked={pendingFilters.category.includes(category)}
                      onChange={() => togglePendingFilter('category', category)}
                    />
                    <div className={`w-4 h-4 border border-zinc-300 mr-3 flex items-center justify-center transition-all ${pendingFilters.category.includes(category) ? 'bg-black border-black' : 'group-hover:border-black'}`}>
                      {pendingFilters.category.includes(category) && <div className="w-1.5 h-1.5 bg-white" />}
                    </div>
                    <span className={`text-sm transition-colors ${pendingFilters.category.includes(category) ? 'text-black font-medium' : 'text-zinc-500 group-hover:text-black'}`}>{category}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Platform Filter */}
            <div>
              <h4 className="text-[10px] uppercase tracking-widest font-bold text-zinc-400 mb-6">Platform</h4>
              <div className="space-y-3">
                {platforms.map(platform => (
                  <label key={platform} className="flex items-center group cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="hidden" 
                      checked={pendingFilters.platform.includes(platform)}
                      onChange={() => togglePendingFilter('platform', platform)}
                    />
                    <div className={`w-4 h-4 border border-zinc-300 mr-3 flex items-center justify-center transition-all ${pendingFilters.platform.includes(platform) ? 'bg-black border-black' : 'group-hover:border-black'}`}>
                      {pendingFilters.platform.includes(platform) && <div className="w-1.5 h-1.5 bg-white" />}
                    </div>
                    <span className={`text-sm transition-colors ${pendingFilters.platform.includes(platform) ? 'text-black font-medium' : 'text-zinc-500 group-hover:text-black'}`}>{platform}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Price Range Filter */}
            <div>
              <h4 className="text-[10px] uppercase tracking-widest font-bold text-zinc-400 mb-6">Price Range (Up to ₹{pendingFilters.priceRange.toLocaleString()})</h4>
              <input 
                type="range" 
                min="0" 
                max="20000" 
                step="500"
                value={pendingFilters.priceRange}
                onChange={(e) => setPendingFilters(prev => ({ ...prev, priceRange: parseInt(e.target.value) }))}
                className="w-full h-1 bg-zinc-200 rounded-lg appearance-none cursor-pointer accent-black mt-4"
              />
              <div className="flex justify-between mt-4 text-[10px] text-zinc-400 font-bold uppercase tracking-widest">
                <span>₹0</span>
                <span>₹20,000</span>
              </div>
            </div>
          </div>

          <div className="mt-12 pt-8 border-t border-zinc-100 flex flex-col sm:flex-row justify-between items-center gap-6">
            <button 
              onClick={clearFilters}
              className="text-[10px] uppercase tracking-widest font-bold text-zinc-400 hover:text-black transition-colors flex items-center"
            >
              <X size={12} className="mr-2" /> Clear All Filters
            </button>
            <button 
              onClick={applyFilters}
              className="w-full sm:w-auto bg-black text-white px-12 py-4 text-[10px] uppercase tracking-widest font-bold hover:bg-zinc-800 transition-all rounded-lg"
            >
              Apply Filters
            </button>
          </div>
        </div>
      )}

      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-10 gap-y-20">
          {filteredProducts.map((product, idx) => (
            <div key={product.id} className="reveal-item" style={{ animationDelay: `${0.05 * idx}s` }}>
              <ProductCard 
                product={product} 
                onAddToCompare={onAddToCompare}
                isInCompare={compareList.some(p => p.id === product.id)}
              />
            </div>
          ))}
        </div>
      ) : (
        <div className="py-40 text-center reveal-item">
          <p className="text-zinc-400 uppercase tracking-widest text-xs">No matching arrivals in current stock.</p>
          <button onClick={clearFilters} className="mt-8 underline text-xs uppercase tracking-widest font-bold">Clear Filters</button>
        </div>
      )}
    </div>
  );
};

export default AllProducts;
