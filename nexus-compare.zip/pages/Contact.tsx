
import React from 'react';
import { Mail, Phone, MapPin, Send } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <div className="pt-32 pb-24 page-enter">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-24 reveal-item">
          <span className="text-[10px] uppercase tracking-[0.4em] font-bold text-zinc-400 mb-4 block">Get in Touch</span>
          <h1 className="text-4xl font-light tracking-tight">How can we assist you?</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24">
          <div className="reveal-item">
            <h2 className="text-2xl font-light mb-8">Let's start a conversation.</h2>
            <p className="text-zinc-500 text-sm leading-relaxed mb-12 max-w-md font-light">
              Whether you're a shopper with feedback, a brand wanting to partner, or interested in collaboration, our team is always happy to connect.
            </p>

            <div className="space-y-8">
              <div className="flex items-center space-x-6">
                <div className="w-12 h-12 bg-zinc-50 rounded-full flex items-center justify-center text-zinc-400">
                  <Mail size={20} />
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-widest font-bold text-zinc-400">Email Address</p>
                  <p className="text-sm">hello@nexus.in</p>
                </div>
              </div>
              <div className="flex items-center space-x-6">
                <div className="w-12 h-12 bg-zinc-50 rounded-full flex items-center justify-center text-zinc-400">
                  <Phone size={20} />
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-widest font-bold text-zinc-400">Mobile Phone</p>
                  <p className="text-sm">+91 98765 43210</p>
                </div>
              </div>
              <div className="flex items-center space-x-6">
                <div className="w-12 h-12 bg-zinc-50 rounded-full flex items-center justify-center text-zinc-400">
                  <MapPin size={20} />
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-widest font-bold text-zinc-400">Main Office</p>
                  <p className="text-sm">Bangalore, Karnataka, India</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-zinc-50 p-12 rounded-3xl reveal-item" style={{ animationDelay: '0.2s' }}>
            <form className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-[10px] uppercase tracking-widest font-bold text-zinc-400 mb-2">First Name</label>
                  <input type="text" className="w-full bg-white border-b border-zinc-200 py-3 px-4 focus:outline-none focus:border-black transition-all text-sm font-light" placeholder="Arjun" />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-widest font-bold text-zinc-400 mb-2">Last Name</label>
                  <input type="text" className="w-full bg-white border-b border-zinc-200 py-3 px-4 focus:outline-none focus:border-black transition-all text-sm font-light" placeholder="Sharma" />
                </div>
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest font-bold text-zinc-400 mb-2">Email Address</label>
                <input type="email" className="w-full bg-white border-b border-zinc-200 py-3 px-4 focus:outline-none focus:border-black transition-all text-sm font-light" placeholder="arjun@email.com" />
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest font-bold text-zinc-400 mb-2">Message</label>
                <textarea rows={4} className="w-full bg-white border-b border-zinc-200 py-3 px-4 focus:outline-none focus:border-black transition-all text-sm font-light resize-none" placeholder="How can we help you?"></textarea>
              </div>
              <button className="w-full bg-black text-white py-5 text-[11px] uppercase tracking-widest font-bold hover:bg-zinc-800 transition-all flex items-center justify-center">
                Send Message <Send size={14} className="ml-2" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
