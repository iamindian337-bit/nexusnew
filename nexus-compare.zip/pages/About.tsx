
import React from 'react';
import { Link } from 'react-router-dom';

const About: React.FC = () => {
  return (
    <div className="pt-20 pb-24 page-enter bg-white">
      {/* Header Section */}
      <section className="bg-black py-20 sm:py-32 px-6 text-center">
        <div className="max-w-7xl mx-auto">
          <span className="text-[10px] uppercase tracking-[0.4em] text-[#C5A059] font-bold mb-6 sm:mb-8 block">Our Purpose</span>
          <h1 className="text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-serif text-white mb-8 sm:mb-12 leading-tight">
            Why pay more when you can <br className="hidden sm:block" />
            <span className="italic">compare and save?</span>
          </h1>
          <p className="max-w-3xl mx-auto text-zinc-400 text-xs sm:text-sm md:text-base leading-relaxed">
            The same product is often listed at different prices across various shopping platforms, but most shoppers don’t realize it. 
            Comparing multiple apps manually can be time-consuming and inconvenient, which means many people end up paying more than 
            necessary without knowing there are better options available.
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-6">
        {/* The Solution Section */}
        <section className="py-16 sm:py-24 border-b border-zinc-100">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div>
              <span className="text-[10px] uppercase tracking-[0.4em] text-zinc-400 font-bold mb-6 block">The Platform</span>
              <h2 className="text-3xl sm:text-4xl font-serif text-zinc-900 mb-6 sm:mb-8">Smart shopping, powered by AI.</h2>
              <p className="text-zinc-500 text-base sm:text-lg leading-relaxed mb-6 sm:mb-8">
                NEXUS is a smart AI-powered price comparison platform that helps you find the lowest price in seconds. We compare real-time prices from top shopping sites like Myntra, Ajio, Flipkart, and Amazon in one place, so you never overpay again.
              </p>
              <div className="space-y-4 mb-10">
                {[
                  'Compare prices across multiple online shopping platforms instantly',
                  'Find the best deals on fashion, footwear, electronics, beauty, and more',
                  'Save money on every purchase with smart price insights',
                  'Shop confidently knowing you’re getting the best price available'
                ].map((item, i) => (
                  <div key={i} className="flex items-start">
                    <div className="w-1.5 h-1.5 rounded-full bg-black mt-2 mr-4 shrink-0" />
                    <p className="text-zinc-600 text-sm sm:text-base">{item}</p>
                  </div>
                ))}
              </div>
              <p className="text-zinc-900 font-medium text-base sm:text-lg leading-relaxed italic">
                NEXUS makes online shopping smarter, faster, and more affordable. Compare prices, discover better deals, and start saving today.
              </p>
            </div>
            <div className="aspect-[4/5] bg-zinc-50 rounded-3xl overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800" 
                alt="Product Comparison" 
                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000"
              />
            </div>
          </div>
        </section>

        {/* The Mission Section */}
        <section className="py-16 sm:py-24 border-b border-zinc-100">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div className="order-2 lg:order-1 aspect-[4/5] bg-zinc-50 rounded-3xl overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=800" 
                alt="Our Mission" 
                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000"
              />
            </div>
            <div className="order-1 lg:order-2">
              <span className="text-[10px] uppercase tracking-[0.4em] text-zinc-400 font-bold mb-6 block">The Mission</span>
              <h2 className="text-3xl sm:text-4xl font-serif text-zinc-900 mb-6 sm:mb-8">Making every rupee count.</h2>
              <p className="text-zinc-500 text-base sm:text-lg leading-relaxed mb-6 sm:mb-8">
                At NEXUS, our mission is to help India’s fashion-conscious shoppers compare prices and make smarter buying decisions. We track product prices across leading platforms like Myntra, Ajio, Flipkart, and Amazon in real time, so you can instantly find the best deals without spending hours searching.
              </p>
              <p className="text-zinc-500 text-base sm:text-lg leading-relaxed mb-10 sm:mb-12">
                NEXUS is a free and independent price comparison platform built entirely for shoppers. We don’t favor any marketplace — our goal is simple: show you the lowest price available and help you save money on every purchase.
              </p>
              <div className="text-4xl sm:text-6xl font-serif text-zinc-100 select-none italic">Value.</div>
            </div>
          </div>
        </section>

        {/* Closing Section */}
        <section className="py-16 sm:py-24">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl sm:text-4xl font-serif text-zinc-900 mb-8">When you save more, we succeed.</h2>
            <p className="text-zinc-500 text-base sm:text-lg leading-relaxed mb-12">
              Whether you're shopping for fashion, footwear, beauty, or everyday essentials, NEXUS ensures you always get the best value for your money.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-8">
              <Link to="/signup" className="w-full sm:w-auto bg-black text-white px-12 py-5 rounded-xl font-bold text-sm hover:bg-zinc-800 transition-all min-w-[200px] sm:min-w-[240px]">
                Start Saving Today
              </Link>
              <Link to="/all-products" className="text-zinc-500 hover:text-black transition-colors text-sm font-bold uppercase tracking-widest">
                Explore Products
              </Link>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default About;
