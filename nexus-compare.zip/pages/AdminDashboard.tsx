
import React, { useState } from 'react';
import { BarChart3, Package, Users, Store, Plus, Trash2, Edit2, LogOut } from 'lucide-react';
import { MOCK_PRODUCTS } from '../constants';

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('analytics');
  const [products, setProducts] = useState(MOCK_PRODUCTS);

  const stats = [
    { label: 'Total Products', value: products.length, icon: Package },
    { label: 'Active Users', value: '1,240', icon: Users },
    { label: 'Platforms', value: '5', icon: Store },
    { label: 'Monthly Traffic', value: '45K', icon: BarChart3 },
  ];

  return (
    <div className="pt-20 min-h-screen flex">
      {/* Sidebar */}
      <aside className="w-72 bg-zinc-900 text-white flex flex-col p-10">
        <div className="mb-12">
          <h1 className="text-xl font-semibold tracking-luxury">ADMIN PANEL</h1>
          <p className="text-zinc-500 text-[10px] uppercase tracking-widest mt-2">Nexus Intelligence</p>
        </div>

        <nav className="flex flex-col space-y-4">
          {[
            { id: 'analytics', icon: BarChart3, label: 'Analytics' },
            { id: 'products', icon: Package, label: 'Products' },
            { id: 'users', icon: Users, label: 'Users' },
            { id: 'platforms', icon: Store, label: 'Platforms' },
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-4 py-3 px-6 rounded-xl transition-all text-xs uppercase tracking-widest font-bold ${activeTab === tab.id ? 'bg-white text-black' : 'text-zinc-400 hover:text-white hover:bg-zinc-800'}`}
            >
              <tab.icon size={18} />
              <span>{tab.label}</span>
            </button>
          ))}
        </nav>

        <button className="mt-auto flex items-center space-x-4 text-zinc-500 hover:text-red-400 transition-colors text-xs uppercase tracking-widest font-bold">
          <LogOut size={18} />
          <span>Exit Admin</span>
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-1 bg-zinc-50/50 p-12 overflow-y-auto">
        {activeTab === 'analytics' && (
          <div className="animate-in fade-in duration-700">
            <h2 className="text-3xl font-light mb-10">System Analytics</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
              {stats.map(stat => (
                <div key={stat.label} className="bg-white p-8 rounded-2xl shadow-sm border border-zinc-100">
                  <stat.icon size={24} className="text-zinc-300 mb-6" />
                  <p className="text-3xl font-bold mb-1">{stat.value}</p>
                  <p className="text-[10px] uppercase tracking-widest font-bold text-zinc-400">{stat.label}</p>
                </div>
              ))}
            </div>

            <div className="bg-white p-10 rounded-2xl border border-zinc-100 shadow-sm">
              <h3 className="text-sm uppercase tracking-widest font-bold mb-8">Recent Activity</h3>
              <div className="space-y-6">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="flex items-center justify-between pb-6 border-b border-zinc-50 last:border-0">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-zinc-100 rounded-lg flex items-center justify-center text-xs font-bold">U{i}</div>
                      <div>
                        <p className="text-sm font-medium">New User Registration</p>
                        <p className="text-[10px] text-zinc-400 uppercase tracking-widest">2 minutes ago</p>
                      </div>
                    </div>
                    <span className="text-[10px] uppercase tracking-widest font-bold text-zinc-300">#924{i}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'products' && (
          <div className="animate-in slide-in-from-right duration-700">
            <div className="flex items-center justify-between mb-10">
              <h2 className="text-3xl font-light">Inventory Management</h2>
              <button className="bg-black text-white px-8 py-3 text-[10px] uppercase tracking-widest font-bold hover:bg-zinc-800 transition-all flex items-center">
                <Plus size={16} className="mr-2" /> Add New Item
              </button>
            </div>

            <div className="bg-white rounded-2xl border border-zinc-100 shadow-sm overflow-hidden">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-zinc-50 text-[10px] uppercase tracking-widest font-bold text-zinc-400">
                    <th className="p-6">Product Information</th>
                    <th className="p-6">Brand</th>
                    <th className="p-6">Base Price</th>
                    <th className="p-6">Status</th>
                    <th className="p-6 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map(p => (
                    <tr key={p.id} className="border-b border-zinc-50 hover:bg-zinc-50/50 transition-colors">
                      <td className="p-6">
                        <div className="flex items-center space-x-4">
                          <img src={p.image} className="w-12 h-12 object-cover rounded-lg grayscale" alt={p.name} />
                          <div>
                            <p className="text-sm font-medium">{p.name}</p>
                            <p className="text-[10px] text-zinc-400 uppercase tracking-widest">{p.category}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-6 text-xs uppercase tracking-widest font-medium">{p.brand}</td>
                      <td className="p-6 text-sm font-bold">₹{p.basePrice}</td>
                      <td className="p-6">
                        <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-[9px] uppercase tracking-widest font-bold">In Stock</span>
                      </td>
                      <td className="p-6 text-right">
                        <div className="flex items-center justify-end space-x-3">
                          <button className="p-2 hover:bg-zinc-100 rounded-lg text-zinc-400 hover:text-black transition-all"><Edit2 size={16} /></button>
                          <button className="p-2 hover:bg-zinc-100 rounded-lg text-zinc-400 hover:text-red-500 transition-all"><Trash2 size={16} /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;
