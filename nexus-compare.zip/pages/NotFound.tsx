
import React from 'react';
import { Link } from 'react-router-dom';

const NotFound: React.FC = () => {
  return (
    <div className="h-screen flex items-center justify-center text-center p-6 page-enter">
      <div>
        <h1 className="text-[12rem] font-bold tracking-tighter leading-none opacity-5 mb-0">404</h1>
        <h2 className="text-3xl font-light tracking-tight -mt-10 mb-8">Page Not Found</h2>
        <p className="text-zinc-500 text-sm max-w-sm mx-auto mb-12 font-light">The piece you are looking for has been removed from the catalog or moved to a different collection.</p>
        <Link to="/" className="bg-black text-white px-12 py-5 text-[11px] uppercase tracking-widest font-bold hover:bg-zinc-800 transition-all">
          Return Home
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
