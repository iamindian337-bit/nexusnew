
import React from 'react';
import { useSearchParams } from 'react-router-dom';
import { MOCK_PRODUCTS } from '../constants';
import ProductCard from '../components/ProductCard';
import { SlidersHorizontal } from 'lucide-react';

const Search: React.FC<{ onAddToCompare: (p: any) => void; compareList: any[] }> = ({ onAddToCompare, compareList }) => {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';

  const filteredProducts = MOCK_PRODUCTS.filter(p => 
    p.name.toLowerCase().includes(query.toLowerCase()) || 
    p.brand.toLowerCase().includes(query.toLowerCase()) ||
    p.category.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="pt-24 sm:pt-32 pb-24 max-w-7xl mx-auto px-4 sm:px-6 page-enter">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-8">
        <div>
          <span className="text-[10px] uppercase tracking-[0.4em] font-bold text-zinc-400 mb-2 block">Search Intelligence</span>
          <h1 className="text-3xl sm:text-4xl font-light tracking-tight">Results for "{query}"</h1>
          <p className="text-zinc-500 text-xs sm:text-sm mt-2">{filteredProducts.length} premium matches found across platforms.</p>
        </div>
        <button className="flex items-center justify-center space-x-3 w-full md:w-auto px-8 py-3 border border-zinc-200 text-[10px] uppercase tracking-widest font-bold hover:bg-black hover:text-white transition-all">
          <SlidersHorizontal size={14} /> <span>Refine Selection</span>
        </button>
      </div>

      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-10 gap-y-20">
          {filteredProducts.map((product, idx) => (
            <div key={product.id} className="reveal-item" style={{ animationDelay: `${0.05 * idx}s` }}>
              <ProductCard 
                product={product} 
                onAddToCompare={onAddToCompare}
                isInCompare={compareList.some(p => p.id === product.id)}
              />
            </div>
          ))}
        </div>
      ) : (
        <div className="py-40 text-center reveal-item">
          <p className="text-zinc-400 uppercase tracking-widest text-xs">No matching arrivals in current stock.</p>
          <button onClick={() => window.history.back()} className="mt-8 underline text-xs uppercase tracking-widest font-bold">View Collections</button>
        </div>
      )}
    </div>
  );
};

export default Search;
