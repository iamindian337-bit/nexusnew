
import React from 'react';

const Privacy: React.FC = () => {
  return (
    <div className="pt-32 pb-24 page-enter">
      <div className="max-w-3xl mx-auto px-6">
        <h1 className="text-4xl font-light tracking-tight mb-12">Privacy Protocol</h1>
        <div className="prose prose-zinc prose-sm space-y-12 text-zinc-500 font-light leading-relaxed">
          <section>
            <h2 className="text-black font-medium text-lg mb-4">1. Intelligence Gathering</h2>
            <p>We collect information you provide when creating an account (name, email), using our comparison tools, and interacting with our platform. We do not collect sensitive financial information.</p>
          </section>
          <section>
            <h2 className="text-black font-medium text-lg mb-4">2. Utilization</h2>
            <p>We use your information to personalize your experience, send relevant deals, and ensure platform security. Your data is your property; we never sell it to third parties.</p>
          </section>
          <section>
            <h2 className="text-black font-medium text-lg mb-4">3. External Links</h2>
            <p>When you redirect to Myntra, Ajio, or Flipkart, you are subject to their own protocols. We may receive commissions from these referrals at no cost to you.</p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Privacy;
