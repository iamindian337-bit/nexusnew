
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { X } from 'lucide-react';
import { authService } from '../services/authService';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await authService.login(email, password);
      navigate('/dashboard');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen pt-20 flex flex-col md:flex-row page-enter relative">
      {/* Close Button */}
      <button 
        onClick={() => navigate('/')}
        className="absolute top-10 right-10 z-[60] p-3 hover:bg-zinc-100 rounded-full transition-all duration-300 text-zinc-400 hover:text-black"
        aria-label="Close"
      >
        <X size={24} strokeWidth={1.5} />
      </button>

      <div className="hidden md:flex flex-1 bg-black text-white p-20 flex-col justify-end relative overflow-hidden">
        <div className="absolute inset-0 opacity-40">
           <img src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=1920" className="w-full h-full object-cover" alt="Login background" />
        </div>
        <div className="relative z-10">
          <h2 className="text-4xl font-light tracking-tight mb-4">Refining Your <br /> <span className="font-semibold">Style Choice.</span></h2>
          <p className="text-zinc-400 text-sm max-w-sm font-light leading-relaxed">Login to access your personalized fashion dashboard, saved price alerts, and curated collections.</p>
        </div>
      </div>
      <div className="flex-1 flex items-center justify-center p-8 md:p-20 bg-white">
        <div className="w-full max-w-md">
          <h1 className="text-2xl font-semibold tracking-luxury mb-2">NEXUS</h1>
          <h2 className="text-sm uppercase tracking-widest text-zinc-400 mb-10">Sign In to Continue</h2>
          
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="reveal-item" style={{ animationDelay: '0.1s' }}>
              <label className="block text-[10px] uppercase tracking-[0.2em] font-bold mb-2 text-zinc-400">Email Address</label>
              <input 
                type="email" 
                required
                className="w-full border-b border-zinc-200 py-3 focus:outline-none focus:border-black transition-all font-light"
                placeholder="email@example.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
              />
            </div>
            <div className="reveal-item" style={{ animationDelay: '0.2s' }}>
              <label className="block text-[10px] uppercase tracking-[0.2em] font-bold mb-2 text-zinc-400">Password</label>
              <input 
                type="password" 
                required
                className="w-full border-b border-zinc-200 py-3 focus:outline-none focus:border-black transition-all font-light"
                placeholder="••••••••"
                value={password}
                onChange={e => setPassword(e.target.value)}
              />
            </div>
            
            <button 
              disabled={loading}
              className="w-full bg-black text-white py-5 text-[11px] uppercase tracking-[0.3em] font-bold hover:bg-zinc-800 transition-all disabled:opacity-50 shadow-xl reveal-item"
              style={{ animationDelay: '0.3s' }}
            >
              {loading ? 'Authenticating...' : 'Sign In'}
            </button>
          </form>

          <div className="mt-12 pt-8 border-t border-zinc-100 text-center reveal-item" style={{ animationDelay: '0.4s' }}>
            <p className="text-[11px] text-zinc-400 uppercase tracking-widest">
              Don't have an account? 
              <Link to="/signup" className="text-black font-bold ml-2 hover:underline">Create Account</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
