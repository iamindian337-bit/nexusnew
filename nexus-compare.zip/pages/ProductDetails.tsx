
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MOCK_PRODUCTS } from '../constants';
import { Product } from '../types';
import { Sparkles, ArrowLeft, ExternalLink, ShieldCheck, Truck, RefreshCcw } from 'lucide-react';
import { getShoppingInsight } from '../services/geminiService';

const ProductDetails: React.FC = () => {
  const { id } = useParams();
  const [product, setProduct] = useState<Product | null>(null);
  const [activeImage, setActiveImage] = useState('');
  const [aiInsight, setAiInsight] = useState<string>('Analyzing market value...');
  const [loadingInsight, setLoadingInsight] = useState(true);

  useEffect(() => {
    const p = MOCK_PRODUCTS.find(item => item.id === id);
    if (p) {
      setProduct(p);
      setActiveImage(p.image);
      fetchInsight(p);
    }
  }, [id]);

  const fetchInsight = async (p: Product) => {
    setLoadingInsight(true);
    const insight = await getShoppingInsight(p);
    setAiInsight(insight);
    setLoadingInsight(false);
  };

  if (!product) return <div className="pt-40 text-center">Loading piece...</div>;

  return (
    <div className="pt-32 pb-24 max-w-7xl mx-auto px-6">
      <Link to="/" className="inline-flex items-center text-xs uppercase tracking-widest font-semibold text-zinc-400 hover:text-black mb-10 transition-colors">
        <ArrowLeft size={16} className="mr-2" /> Back to Collections
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        {/* Gallery */}
        <div className="space-y-6">
          <div className="aspect-[3/4] bg-zinc-100 overflow-hidden">
            <img src={activeImage} className="w-full h-full object-cover transition-opacity duration-500" alt={product.name} />
          </div>
          <div className="grid grid-cols-4 gap-4">
            {product.gallery.map((img, i) => (
              <button 
                key={i} 
                onClick={() => setActiveImage(img)}
                className={`aspect-[3/4] overflow-hidden border-2 ${activeImage === img ? 'border-black' : 'border-transparent'}`}
              >
                <img src={img} className="w-full h-full object-cover" alt={`${product.name} view ${i}`} />
              </button>
            ))}
          </div>
        </div>

        {/* Info */}
        <div className="flex flex-col">
          <span className="text-xs uppercase tracking-[0.4em] text-zinc-400 font-medium mb-2">{product.brand}</span>
          <h1 className="text-4xl font-light mb-4">{product.name}</h1>
          
          <div className="flex items-center space-x-4 mb-8">
            <span className="text-2xl font-bold">₹{product.basePrice}</span>
            <span className="px-3 py-1 bg-zinc-100 text-[10px] uppercase tracking-widest font-bold">In Stock</span>
          </div>

          {/* AI Box */}
          <div className="bg-zinc-50 border-l-4 border-black p-6 mb-10">
            <div className="flex items-center mb-3 text-xs uppercase tracking-widest font-bold">
              <Sparkles size={14} className="mr-2" /> NEXUS AI Insights
            </div>
            <p className="text-sm text-zinc-600 leading-relaxed italic">
              {loadingInsight ? (
                <span className="animate-pulse">Synthesizing expert shopping advice...</span>
              ) : (
                `"${aiInsight}"`
              )}
            </p>
          </div>

          <p className="text-zinc-500 text-sm leading-relaxed mb-10">
            {product.description}
          </p>

          <h3 className="text-xs uppercase tracking-widest font-bold mb-6">Compare Marketplace Availability</h3>
          <div className="space-y-4 mb-10">
            {product.prices.map(item => (
              <div key={item.platform} className="flex items-center justify-between p-4 border border-zinc-100 hover:border-black transition-all group">
                <div className="flex items-center space-x-4">
                  <span className="text-sm font-medium">{item.platform}</span>
                  <span className="text-sm font-bold">₹{item.price}</span>
                </div>
                <a 
                  href={item.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[10px] uppercase tracking-widest font-bold flex items-center text-zinc-400 group-hover:text-black transition-colors"
                >
                  Purchase Now <ExternalLink size={12} className="ml-1" />
                </a>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-3 gap-4 border-t border-zinc-100 pt-10">
            <div className="flex flex-col items-center text-center">
              <ShieldCheck size={20} className="mb-2 text-zinc-400" />
              <span className="text-[10px] uppercase tracking-widest font-medium">Authentic Only</span>
            </div>
            <div className="flex flex-col items-center text-center">
              <Truck size={20} className="mb-2 text-zinc-400" />
              <span className="text-[10px] uppercase tracking-widest font-medium">Global Shipping</span>
            </div>
            <div className="flex flex-col items-center text-center">
              <RefreshCcw size={20} className="mb-2 text-zinc-400" />
              <span className="text-[10px] uppercase tracking-widest font-medium">14 Day Return</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;
