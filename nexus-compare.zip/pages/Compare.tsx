
import React from 'react';
import { X, ExternalLink, ShoppingCart, TrendingDown } from 'lucide-react';
import { Product } from '../types';

interface CompareProps {
  compareList: Product[];
  onRemove: (id: string) => void;
  onClear: () => void;
}

const Compare: React.FC<CompareProps> = ({ compareList, onRemove, onClear }) => {
  if (compareList.length === 0) {
    return (
      <div className="pt-40 pb-20 max-w-7xl mx-auto px-6 text-center">
        <h1 className="text-4xl font-light mb-6">Compare Your Finds</h1>
        <p className="text-zinc-500 mb-10">You haven't added any products to compare yet.</p>
        <button 
          onClick={() => window.location.href = '#/'}
          className="bg-black text-white px-10 py-4 text-xs uppercase tracking-widest font-semibold"
        >
          Explore Collection
        </button>
      </div>
    );
  }

  const platforms = ['Myntra', 'Ajio', 'Flipkart', 'Amazon'];

  const getBestPrice = (product: Product) => {
    return Math.min(...product.prices.map(p => p.price));
  };

  return (
    <div className="pt-24 sm:pt-32 pb-24 max-w-7xl mx-auto px-4 sm:px-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-12 gap-6">
        <div>
          <h1 className="text-3xl sm:text-4xl font-light tracking-tight">Marketplace Intelligence</h1>
          <p className="text-zinc-500 text-xs sm:text-sm mt-2">Precision pricing across the industry's leaders.</p>
        </div>
        <button 
          onClick={onClear}
          className="text-[10px] uppercase tracking-widest text-zinc-400 hover:text-black transition-colors text-left"
        >
          Clear Selection
        </button>
      </div>

      <div className="overflow-x-auto no-scrollbar -mx-4 px-4 sm:mx-0 sm:px-0">
        <table className="w-full border-collapse min-w-[600px]">
          <thead>
            <tr>
              <th className="p-6 text-left border-b border-zinc-100 bg-zinc-50/50 w-64">
                <span className="text-[10px] uppercase tracking-widest text-zinc-400 font-semibold">Attributes</span>
              </th>
              {compareList.map(product => (
                <th key={product.id} className="p-6 border-b border-zinc-100 min-w-[280px] relative group">
                  <button 
                    onClick={() => onRemove(product.id)}
                    className="absolute top-4 right-4 p-1 hover:bg-zinc-100 rounded-full transition-all"
                  >
                    <X size={16} />
                  </button>
                  <div className="flex flex-col items-center">
                    <img src={product.image} className="w-32 h-40 object-cover mb-4 grayscale hover:grayscale-0 transition-all" alt={product.name} />
                    <span className="text-[10px] uppercase tracking-widest text-zinc-400">{product.brand}</span>
                    <h3 className="text-sm font-medium mt-1 text-center">{product.name}</h3>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {platforms.map(platform => (
              <tr key={platform} className="hover:bg-zinc-50/50 transition-colors">
                <td className="p-6 border-b border-zinc-100 font-medium text-sm text-zinc-500">{platform}</td>
                {compareList.map(product => {
                  const platformData = product.prices.find(p => p.platform === platform);
                  const isBest = platformData?.price === getBestPrice(product);
                  return (
                    <td key={product.id} className={`p-6 border-b border-zinc-100 text-center ${isBest ? 'bg-zinc-50' : ''}`}>
                      <div className="flex flex-col items-center">
                        <span className={`text-lg ${isBest ? 'font-bold text-black' : 'font-light text-zinc-600'}`}>
                          ₹{platformData?.price || 'N/A'}
                        </span>
                        {isBest && (
                          <span className="text-[10px] uppercase tracking-widest font-bold text-green-600 flex items-center mt-1">
                            <TrendingDown size={10} className="mr-1" /> Best Price
                          </span>
                        )}
                        <a 
                          href={platformData?.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="mt-4 text-[10px] uppercase tracking-widest font-semibold flex items-center text-zinc-400 hover:text-black transition-colors"
                        >
                          Shop {platform} <ExternalLink size={12} className="ml-1" />
                        </a>
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
            <tr>
              <td className="p-6 text-sm text-zinc-500">Call to Action</td>
              {compareList.map(product => (
                <td key={product.id} className="p-6 text-center">
                  <button className="bg-black text-white w-full py-4 text-[11px] uppercase tracking-widest font-semibold flex items-center justify-center hover:bg-zinc-800 transition-all">
                    <ShoppingCart size={14} className="mr-2" /> Purchase Piece
                  </button>
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Compare;
