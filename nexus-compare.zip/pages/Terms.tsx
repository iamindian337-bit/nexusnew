
import React from 'react';

const Terms: React.FC = () => {
  return (
    <div className="pt-32 pb-24 page-enter">
      <div className="max-w-3xl mx-auto px-6">
        <h1 className="text-4xl font-light tracking-tight mb-12">Terms of Access</h1>
        <div className="prose prose-zinc prose-sm space-y-12 text-zinc-500 font-light leading-relaxed">
          <section>
            <h2 className="text-black font-medium text-lg mb-4">1. Acceptance</h2>
            <p>By accessing NEXUS, you agree to these Terms. If you do not agree, please cease use of our platform immediately. We reserve the right to update these terms.</p>
          </section>
          <section>
            <h2 className="text-black font-medium text-lg mb-4">2. Accuracy</h2>
            <p>While we strive for precision, marketplace prices change rapidly. NEXUS does not guarantee the absolute accuracy of external prices. Always verify the final amount on the retailer site.</p>
          </section>
          <section>
            <h2 className="text-black font-medium text-lg mb-4">3. Ownership</h2>
            <p>The NEXUS interface, code, and curated branding are protected under international copyright law. Unauthorized duplication is strictly prohibited.</p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Terms;
