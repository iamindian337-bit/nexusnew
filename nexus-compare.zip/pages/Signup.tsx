
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { X } from 'lucide-react';
import { authService } from '../services/authService';

const Signup: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [gender, setGender] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await authService.signup(name, email, password);
      // In a real app, we'd also save phone and gender
      navigate('/dashboard');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen pt-20 flex flex-col md:flex-row page-enter relative">
      {/* Close Button */}
      <button 
        onClick={() => navigate('/')}
        className="absolute top-10 right-10 z-[60] p-3 hover:bg-zinc-100 rounded-full transition-all duration-300 text-zinc-400 hover:text-black"
        aria-label="Close"
      >
        <X size={24} strokeWidth={1.5} />
      </button>

      <div className="hidden md:flex flex-1 bg-zinc-900 text-white p-20 flex-col justify-end relative overflow-hidden">
        <div className="absolute inset-0 opacity-30">
           <img src="https://images.unsplash.com/photo-1488161628813-04466f872be2?q=80&w=1920" className="w-full h-full object-cover" alt="Signup background" />
        </div>
        <div className="relative z-10">
          <h2 className="text-4xl font-light tracking-tight mb-4">A New Era of <br /> <span className="font-semibold">Curated Luxury.</span></h2>
          <p className="text-zinc-400 text-sm max-w-sm font-light leading-relaxed">Gain exclusive access to price tracking, personalized curation, and the ultimate fashion intelligence tool used by professionals.</p>
        </div>
      </div>
      <div className="flex-1 flex items-center justify-center p-8 md:p-20 bg-white overflow-y-auto">
        <div className="w-full max-w-md my-auto">
          <h1 className="text-2xl font-semibold tracking-luxury mb-2">NEXUS</h1>
          <h2 className="text-sm uppercase tracking-widest text-zinc-400 mb-10">Create Your Account</h2>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="reveal-item" style={{ animationDelay: '0.1s' }}>
              <label className="block text-[10px] uppercase tracking-[0.2em] font-bold mb-2 text-zinc-400">Full Name</label>
              <input 
                type="text" 
                required
                className="w-full border-b border-zinc-200 py-3 focus:outline-none focus:border-black transition-all font-light text-sm"
                placeholder="Enter your name"
                value={name}
                onChange={e => setName(e.target.value)}
              />
            </div>
            <div className="reveal-item" style={{ animationDelay: '0.2s' }}>
              <label className="block text-[10px] uppercase tracking-[0.2em] font-bold mb-2 text-zinc-400">Email Address</label>
              <input 
                type="email" 
                required
                className="w-full border-b border-zinc-200 py-3 focus:outline-none focus:border-black transition-all font-light text-sm"
                placeholder="yourname@domain.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
              />
            </div>
            <div className="reveal-item" style={{ animationDelay: '0.3s' }}>
              <label className="block text-[10px] uppercase tracking-[0.2em] font-bold mb-2 text-zinc-400">Mobile Number</label>
              <input 
                type="tel" 
                required
                className="w-full border-b border-zinc-200 py-3 focus:outline-none focus:border-black transition-all font-light text-sm"
                placeholder="+91 00000 00000"
                value={phone}
                onChange={e => setPhone(e.target.value)}
              />
            </div>

            <div className="reveal-item" style={{ animationDelay: '0.4s' }}>
              <label className="block text-[10px] uppercase tracking-[0.2em] font-bold mb-3 text-zinc-400">Gender Selection</label>
              <div className="flex space-x-6">
                {['Male', 'Female', 'Other'].map(opt => (
                  <label key={opt} className="flex items-center space-x-2 cursor-pointer group">
                    <input 
                      type="radio" 
                      name="gender" 
                      value={opt}
                      checked={gender === opt}
                      onChange={e => setGender(e.target.value)}
                      className="accent-black"
                    />
                    <span className="text-xs uppercase tracking-widest text-zinc-600 group-hover:text-black transition-colors">{opt}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="reveal-item" style={{ animationDelay: '0.5s' }}>
              <label className="block text-[10px] uppercase tracking-[0.2em] font-bold mb-2 text-zinc-400">Create Password</label>
              <input 
                type="password" 
                required
                className="w-full border-b border-zinc-200 py-3 focus:outline-none focus:border-black transition-all font-light text-sm"
                placeholder="Minimum 8 characters"
                value={password}
                onChange={e => setPassword(e.target.value)}
              />
            </div>
            
            <button 
              disabled={loading}
              className="w-full bg-black text-white py-5 text-[11px] uppercase tracking-[0.3em] font-bold hover:bg-zinc-800 transition-all disabled:opacity-50 shadow-xl reveal-item mt-4"
              style={{ animationDelay: '0.6s' }}
            >
              {loading ? 'Creating Profile...' : 'Complete Registration'}
            </button>
          </form>

          <div className="mt-12 pt-8 border-t border-zinc-100 text-center reveal-item" style={{ animationDelay: '0.7s' }}>
            <p className="text-[11px] text-zinc-400 uppercase tracking-widest">
              Already have an account? 
              <Link to="/login" className="text-black font-bold ml-2 hover:underline">Sign In</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;
