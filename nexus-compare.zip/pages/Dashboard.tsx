
import React from 'react';
import { User, LogOut, Heart, Clock, Settings, ArrowRight } from 'lucide-react';
import { authService } from '../services/authService';
import { useNavigate } from 'react-router-dom';
import { MOCK_PRODUCTS } from '../constants';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { user } = authService.getCurrentUser();

  const handleLogout = () => {
    authService.logout();
    navigate('/login');
  };

  if (!user) {
    navigate('/login');
    return null;
  }

  const favoriteProducts = MOCK_PRODUCTS.filter(p => user.favorites.includes(p.id));

  return (
    <div className="pt-20 min-h-screen flex">
      {/* Sidebar */}
      <aside className="w-64 border-r border-zinc-100 hidden md:flex flex-col p-8 space-y-8 bg-zinc-50/50">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-black text-white rounded-full flex items-center justify-center font-bold">
            {user.name.charAt(0)}
          </div>
          <div>
            <p className="text-xs font-bold uppercase tracking-widest">{user.name}</p>
            <p className="text-[10px] text-zinc-400 uppercase tracking-widest">Premium Member</p>
          </div>
        </div>

        <nav className="flex flex-col space-y-4">
          <button className="flex items-center space-x-3 text-xs uppercase tracking-widest font-semibold text-black">
            <User size={16} /> <span>Profile</span>
          </button>
          <button className="flex items-center space-x-3 text-xs uppercase tracking-widest font-semibold text-zinc-400 hover:text-black transition-colors">
            <Heart size={16} /> <span>Wishlist</span>
          </button>
          <button className="flex items-center space-x-3 text-xs uppercase tracking-widest font-semibold text-zinc-400 hover:text-black transition-colors">
            <Clock size={16} /> <span>History</span>
          </button>
          <button className="flex items-center space-x-3 text-xs uppercase tracking-widest font-semibold text-zinc-400 hover:text-black transition-colors">
            <Settings size={16} /> <span>Settings</span>
          </button>
        </nav>

        <button 
          onClick={handleLogout}
          className="mt-auto flex items-center space-x-3 text-xs uppercase tracking-widest font-semibold text-red-500 hover:text-red-700 transition-colors"
        >
          <LogOut size={16} /> <span>Sign Out</span>
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 md:p-16">
        <div className="mb-12">
          <h1 className="text-3xl font-light mb-2">Welcome Back, {user.name.split(' ')[0]}</h1>
          <p className="text-zinc-500 text-sm">Your fashion intelligence dashboard.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          <div className="bg-black text-white p-8">
            <p className="text-[10px] uppercase tracking-[0.4em] mb-4">Active Comparison</p>
            <h3 className="text-2xl font-light mb-6">Currently tracking 4 items for price drops.</h3>
            <button className="flex items-center text-xs uppercase tracking-widest font-bold group">
              View Tracking <ArrowRight size={14} className="ml-2 group-hover:translate-x-1 transition-all" />
            </button>
          </div>
          <div className="border border-zinc-100 p-8 flex flex-col justify-center">
            <p className="text-[10px] uppercase tracking-[0.4em] text-zinc-400 mb-4">Savings Insight</p>
            <h3 className="text-2xl font-light mb-2">₹12,400 Saved</h3>
            <p className="text-zinc-500 text-xs">Total saved using Nexus comparison since joining.</p>
          </div>
        </div>

        <h2 className="text-xs uppercase tracking-[0.4em] font-bold mb-8">Your Favorites</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {favoriteProducts.map(product => (
            <div key={product.id} className="flex space-x-4 border-b border-zinc-100 pb-6">
              <img src={product.image} className="w-20 h-24 object-cover grayscale" alt={product.name} />
              <div className="flex flex-col justify-center">
                <span className="text-[10px] uppercase tracking-widest text-zinc-400">{product.brand}</span>
                <p className="text-sm font-medium">{product.name}</p>
                <p className="text-sm font-bold mt-1">₹{product.basePrice}</p>
                <button className="text-[10px] uppercase tracking-widest font-bold mt-3 hover:underline">Remove</button>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
