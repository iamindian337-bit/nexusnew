
import React from 'react';
import { ArrowLeft, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

const PLATFORMS = [
  {
    name: 'Myntra',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQ0vc0hgelONOuuyS9XE7ouD-fPC-byaZGxA&s',
    url: 'https://www.myntra.com',
    description: "India's leading lifestyle fashion destination with a curated range of high-end brands."
  },
  {
    name: 'Ajio',
    logo: 'https://assets-jiocdn.ajio.com/static/img/Ajio-Logo.svg',
    url: 'https://www.ajio.com',
    description: 'A fashion-first marketplace bringing international luxury and designer labels to your doorstep.'
  },
  {
    name: 'Flipkart',
    logo: 'https://rukminim2.flixcart.com/fk-p-flap/92/36/image/31f7e3af490c225f.png?q=60',
    url: 'https://www.flipkart.com',
    description: "One of India's largest marketplaces with a massive collection of fashion for every budget."
  },
  {
    name: 'Meesho',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/33/Meesho_logo.png/250px-Meesho_logo.png',
    url: 'https://www.meesho.com',
    description: 'India’s fastest-growing social commerce platform, offering a wide variety of affordable fashion.'
  },
  {
    name: 'Amazon',
    logo: 'https://www.vectorlogo.zone/logos/amazon/amazon-icon.svg',
    url: 'https://www.amazon.in',
    description: 'Global giant offering a reliable shopping experience with an extensive selection of premium wear.'
  }
];

const Platforms: React.FC = () => {
  return (
    <div className="pt-32 pb-24 max-w-7xl mx-auto px-6 page-enter">
      <Link to="/" className="inline-flex items-center text-xs uppercase tracking-widest font-semibold text-zinc-400 hover:text-black mb-10 transition-colors">
        <ArrowLeft size={16} className="mr-2" /> Back to Collections
      </Link>

      <div className="mb-16 reveal-item">
        <h1 className="text-4xl font-light tracking-tight">Our Integrated Platforms</h1>
        <p className="text-zinc-500 text-sm mt-2 max-w-2xl font-light">
          NEXUS aggregates real-time intelligence from the industry's most reputable luxury and lifestyle marketplaces.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {PLATFORMS.map((platform, idx) => (
          <a
            key={platform.name}
            href={platform.url}
            target="_blank"
            rel="noopener noreferrer"
            className="group block p-10 border border-zinc-100 hover:border-black transition-all duration-500 bg-zinc-50/30 reveal-item"
            style={{ animationDelay: `${0.1 * idx}s` }}
          >
            <div className="flex items-center justify-between mb-8 h-12">
              <img src={platform.logo} alt={platform.name} className="h-10 object-contain grayscale-0 group-hover:grayscale transition-all duration-500" />
              <ExternalLink size={20} className="text-zinc-300 group-hover:text-black transition-colors" />
            </div>
            <h3 className="text-xl font-medium mb-3">{platform.name}</h3>
            <p className="text-sm text-zinc-500 leading-relaxed mb-6 font-light">{platform.description}</p>
            <span className="text-[10px] uppercase tracking-widest font-bold group-hover:underline">Explore Official Catalog</span>
          </a>
        ))}
      </div>
    </div>
  );
};

export default Platforms;
