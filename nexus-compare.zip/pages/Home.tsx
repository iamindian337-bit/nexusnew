
import React, { useRef, useEffect, useState } from 'react';
import { ChevronDown, Search } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { MOCK_PRODUCTS } from '../constants';
import { Product } from '../types';
import { Link, useNavigate } from 'react-router-dom';

interface HomeProps {
  onAddToCompare: (p: Product) => void;
  compareList: Product[];
  searchQuery: string;
}

const AnimatedCounter: React.FC<{ end: number; duration?: number; suffix?: string; prefix?: string; locale?: string }> = ({ end, duration = 2000, suffix = '', prefix = '', locale = 'en-US' }) => {
  const [count, setCount] = useState(0);
  const [hasStarted, setHasStarted] = useState(false);
  const elementRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasStarted) {
          setHasStarted(true);
        }
      },
      { threshold: 0.1 }
    );

    if (elementRef.current) {
      observer.observe(elementRef.current);
    }

    return () => observer.disconnect();
  }, [hasStarted]);

  useEffect(() => {
    if (!hasStarted) return;

    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * end));
      if (progress < 1) {
        window.requestAnimationFrame(step);
      }
    };
    window.requestAnimationFrame(step);
  }, [hasStarted, end, duration]);

  return <span ref={elementRef}>{prefix}{count.toLocaleString(locale)}{suffix}</span>;
};

const Home: React.FC<HomeProps> = ({ onAddToCompare, compareList, searchQuery }) => {
  const collectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [localSearch, setLocalSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const navigate = useNavigate();

  const handleLocalSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (localSearch.trim()) {
      navigate(`/search?q=${localSearch}`);
    }
  };

  const tags = ['Sneakers', 'Kurta', 'Jeans', 'Dresses', 'Hoodies'];

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const scrollToCollection = () => {
    collectionRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const filteredProducts = MOCK_PRODUCTS.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const categories = [
    { name: 'Ethnic Wear', image: 'https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcRB4BuvBS9168uubpYrr--onSKvmNNAsOIFrK1bydLlvXNIMbHesU4KHslaXZ0LEOBoz86qKBvevxXT8uXw7LWsCcO_F8zpomzKnaAq3-zC8E4XQnQesEoHmQ' },
    { name: 'Western Dresses', image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400' },
    { name: 'Menswear', image: 'https://images.unsplash.com/photo-1488161628813-04466f872be2?w=400' },
    { name: 'Footwear', image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400' },
    { name: 'Home Decor', image: 'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?w=400' },
    { name: 'Beauty', image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=400' },
    { name: 'Accessories', image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400' },
    { name: 'Grocery', image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400' },
    { name: 'Sneakers', image: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?w=400' },
    { name: 'Kurtas', image: 'https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=400' },
  ];

  const trendingProducts = MOCK_PRODUCTS.filter(p => {
    if (activeFilter === 'All') return true;
    return p.gender === activeFilter;
  }).slice(0, 8);

  const platforms = [
    { name: 'Myntra', url: 'https://www.myntra.com', logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQ0vc0hgelONOuuyS9XE7ouD-fPC-byaZGxA&s' },
    { name: 'Ajio', url: 'https://www.ajio.com', logo: 'https://assets-jiocdn.ajio.com/static/img/Ajio-Logo.svg' },
    { name: 'Flipkart', url: 'https://rukminim2.flixcart.com/fk-p-flap/92/36/image/31f7e3af490c225f.png?q=60', logo: 'https://rukminim2.flixcart.com/fk-p-flap/92/36/image/31f7e3af490c225f.png?q=60' },
    { name: 'Meesho', url: 'https://www.meesho.com', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/33/Meesho_logo.png/250px-Meesho_logo.png' },
    { name: 'Amazon', url: 'https://www.amazon.in', logo: 'https://www.vectorlogo.zone/logos/amazon/amazon-icon.svg' }
  ];

  const marqueePlatforms = [...platforms, ...platforms, ...platforms];

  return (
    <div className={`pt-20 transition-opacity duration-1000 ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
      {/* Updated Hero Section with Zoom Out effect */}
      {!searchQuery && (
        <div className="relative h-[85vh] flex items-center justify-center overflow-hidden bg-black">
          <div className="absolute inset-0 z-0 overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1558769132-cb1aea458c5e?q=80&w=1920" 
              className="w-full h-full object-cover object-top brightness-[0.7] animate-zoom-out"
              alt="Luxury fashion background"
            />
          </div>
          <div className="relative z-10 text-center text-white px-6">
            <span className="text-[10px] md:text-[12px] uppercase tracking-[0.8em] font-medium mb-4 block reveal-item" style={{ animationDelay: '0.2s' }}>
              AUTUMN / WINTER 2024
            </span>
            <h1 className="flex flex-col items-center reveal-item" style={{ animationDelay: '0.4s' }}>
              <span className="text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-light tracking-tight mb-0">The Art of</span>
              <span className="text-5xl sm:text-6xl md:text-8xl lg:text-9xl font-bold tracking-tighter leading-none">Pure Comparison</span>
            </h1>
            <p className="max-w-2xl mx-auto text-xs sm:text-sm md:text-lg font-light text-zinc-200 mt-8 mb-12 reveal-item leading-relaxed" style={{ animationDelay: '0.6s' }}>
              Discover fashion curated from global platforms. Side-by-side pricing for the discerning eye.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6 reveal-item" style={{ animationDelay: '0.8s' }}>
              <button 
                onClick={scrollToCollection}
                className="w-full sm:w-auto bg-white text-black px-12 py-4 sm:py-5 text-[10px] sm:text-[11px] uppercase tracking-[0.2em] font-bold hover:bg-zinc-100 transition-all duration-500 shadow-2xl"
              >
                EXPLORE ACCESS
              </button>
              <Link 
                to="/platforms"
                className="w-full sm:w-auto border border-white text-white px-12 py-4 sm:py-5 text-[10px] sm:text-[11px] uppercase tracking-[0.2em] font-bold hover:bg-white hover:text-black transition-all duration-500"
              >
                VIEW PLATFORMS
              </Link>
            </div>
          </div>
          <button 
            onClick={scrollToCollection}
            className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white animate-bounce opacity-60 hover:opacity-100 transition-opacity z-10"
          >
            <ChevronDown size={32} strokeWidth={1} />
          </button>
        </div>
      )}

      {/* Search Section */}
      <section className="bg-zinc-50/50 py-16 sm:py-24 px-6 border-b border-zinc-100">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-zinc-400 text-[10px] sm:text-sm uppercase tracking-widest mb-8">Search. Four platforms. The lowest price wins.</h2>
          
          <form onSubmit={handleLocalSearch} className="flex flex-col sm:flex-row items-stretch shadow-sm mb-8">
            <input 
              type="text" 
              placeholder="Try 'White sneakers'..."
              className="flex-grow bg-white border border-zinc-200 px-6 py-4 text-base sm:text-lg focus:outline-none focus:border-zinc-400 transition-colors"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
            />
            <button 
              type="submit"
              className="bg-black text-white px-10 py-4 flex items-center justify-center space-x-3 hover:bg-zinc-800 transition-all font-medium"
            >
              <Search size={20} />
              <span>Search</span>
            </button>
          </form>

          <div className="flex flex-wrap justify-center gap-2 sm:gap-3">
            {tags.map(tag => (
              <button 
                key={tag}
                onClick={() => {
                  setLocalSearch(tag);
                  navigate(`/search?q=${tag}`);
                }}
                className="px-4 sm:px-6 py-2 bg-white border border-zinc-200 rounded-full text-xs sm:text-sm text-zinc-600 hover:border-black hover:text-black transition-all shadow-sm"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Category Scroller - Perfectly Centered */}
      {!searchQuery && (
        <section className="py-12 bg-white overflow-hidden border-b border-zinc-100">
          <div className="max-w-[1400px] mx-auto px-6 overflow-x-auto no-scrollbar">
            <div className="flex items-center justify-start md:justify-center space-x-8 md:space-x-12 pb-4 min-w-max">
              {categories.map((cat, idx) => (
                <div 
                  key={cat.name} 
                  onClick={() => navigate(`/search?q=${cat.name}`)}
                  className="flex-shrink-0 flex flex-col items-center group cursor-pointer reveal-item text-center" 
                  style={{ animationDelay: `${0.1 * idx}s` }}
                >
                  <div className="w-20 h-28 sm:w-24 sm:h-32 md:w-32 md:h-44 bg-[#F8F0F5] rounded-t-full overflow-hidden mb-4 transition-transform duration-500 group-hover:scale-105 shadow-sm">
                    <img src={cat.image} alt={cat.name} className="w-full h-full object-cover grayscale-0 group-hover:grayscale transition-all duration-700" />
                  </div>
                  <span className="text-[10px] sm:text-[11px] md:text-xs font-medium text-zinc-600 tracking-tight group-hover:text-black transition-colors whitespace-nowrap">
                    {cat.name}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Row Type Platform Logos Marquee - Centered Header and continuous scroll */}
      {!searchQuery && (
        <section className="bg-white py-14 border-b border-zinc-100 overflow-hidden">
          <div className="max-w-7xl mx-auto px-6 mb-12 flex flex-col items-center justify-center text-center gap-4 relative">
            <div className="reveal-item">
              <p className="text-[10px] uppercase tracking-[0.4em] text-zinc-400 font-bold mb-2">Live Integration</p>
              <h2 className="text-2xl font-light tracking-tight">Direct Platform Access</h2>
            </div>
            <Link to="/platforms" className="md:absolute md:right-6 md:top-1/2 md:-translate-y-1/2 text-[10px] uppercase tracking-widest font-bold text-zinc-300 hover:text-black transition-colors">
              Launch Directory
            </Link>
          </div>

          <div className="relative w-full overflow-hidden bg-zinc-50/40 py-10">
            <div className="animate-marquee-horizontal flex items-center">
              {marqueePlatforms.map((platform, index) => (
                <a 
                  key={`${platform.name}-${index}`}
                  href={platform.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mx-16 flex flex-col items-center group transition-all duration-500"
                >
                  <div className="h-10 w-32 flex items-center justify-center">
                    <img 
                      src={platform.logo} 
                      alt={platform.name} 
                      className="max-h-full max-w-full object-contain grayscale-0 group-hover:grayscale transition-all duration-700 opacity-100 group-hover:opacity-70"
                    />
                  </div>
                </a>
              ))}
            </div>
            <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
            <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>
          </div>
        </section>
      )}

      {/* Product Grid */}
      <section ref={collectionRef} className="max-w-7xl mx-auto px-6 py-16 sm:py-24">
        <div className="text-center mb-12 sm:mb-16">
          <p className="text-[10px] uppercase tracking-[0.4em] text-[#C5A059] font-bold mb-4">Trending Now</p>
          <h2 className="text-3xl sm:text-5xl font-serif text-zinc-900 mb-8 sm:mb-12">
            {searchQuery ? `Refined results for "${searchQuery}"` : 'Featured Collections'}
          </h2>
          
          {!searchQuery && (
            <div className="flex items-center justify-center space-x-2 sm:space-x-4 overflow-x-auto no-scrollbar pb-2">
              {['All', 'Men', 'Women', 'Unisex'].map((filter) => (
                <button 
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className={`px-6 sm:px-8 py-2 sm:py-2.5 rounded-full text-[10px] sm:text-xs font-medium transition-all whitespace-nowrap ${filter === activeFilter ? 'bg-black text-white' : 'bg-white border border-zinc-100 text-zinc-500 hover:border-zinc-300'}`}
                >
                  {filter}
                </button>
              ))}
            </div>
          )}
        </div>

        {trendingProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-10 gap-y-20">
            {trendingProducts.map((product, idx) => (
              <div key={product.id} className="reveal-item" style={{ animationDelay: `${0.1 * idx}s` }}>
                <ProductCard 
                  product={product} 
                  onAddToCompare={onAddToCompare}
                  isInCompare={compareList.some(p => p.id === product.id)}
                />
              </div>
            ))}
          </div>
        ) : (
          <div className="py-32 text-center reveal-item">
            <p className="text-zinc-400 uppercase tracking-widest text-xs">No matching arrivals in current stock.</p>
          </div>
        )}

        {/* View All Products Button */}
        {!searchQuery && (
          <div className="mt-16 text-center">
            <Link 
              to="/all-products"
              className="inline-block bg-black text-white px-12 py-5 text-[11px] uppercase tracking-[0.2em] font-bold hover:bg-zinc-800 transition-all shadow-xl rounded-xl"
            >
              View All Products
            </Link>
          </div>
        )}

        {/* Brand Text Ticker */}
        {!searchQuery && (
          <div className="mt-32 pt-24 border-t border-zinc-100 overflow-hidden">
            <div className="max-w-7xl mx-auto px-6 text-center mb-16">
              <p className="text-[10px] uppercase tracking-[0.4em] text-[#C5A059] font-bold mb-4">Featured Brands</p>
              <h2 className="text-4xl font-serif text-zinc-900">Top fashion brands, compared</h2>
            </div>
            <div className="animate-marquee-horizontal pause-on-hover flex items-center py-10 bg-zinc-50/50">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="flex items-center">
                  {['H&M', 'Zara', 'Nike', 'Adidas', 'Levis', 'W', 'Biba', 'Fabindia', 'Mango', 'Only', 'Vero Moda', 'Jack & Jones'].map((brand) => (
                    <span 
                      key={`${brand}-${i}`} 
                      className="mx-12 text-xl font-bold uppercase tracking-[0.2em] text-zinc-900 whitespace-nowrap"
                    >
                      {brand}
                    </span>
                  ))}
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Newsletter Section */}
      {!searchQuery && (
        <section className="bg-zinc-900 py-24 px-6 text-white overflow-hidden relative">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-12 relative z-10">
            <div className="max-w-xl">
              <h2 className="text-4xl font-light tracking-tight mb-4">Join the Inner Circle</h2>
              <p className="text-zinc-400 text-sm leading-relaxed">
                Subscribe to receive exclusive access to price drops, luxury curated collections, and private sales events.
              </p>
            </div>
            <form className="w-full md:w-auto flex flex-col sm:flex-row gap-4">
              <input 
                type="email" 
                placeholder="Enter your email address"
                className="bg-zinc-800 border border-zinc-700 px-6 py-4 text-sm focus:outline-none focus:border-white transition-colors min-w-[300px]"
              />
              <button className="bg-white text-black px-10 py-4 text-xs font-bold uppercase tracking-widest hover:bg-zinc-200 transition-all">
                Subscribe
              </button>
            </form>
          </div>
          {/* Decorative background text */}
          <div className="absolute -bottom-10 -right-10 text-[200px] font-bold text-white/[0.03] select-none pointer-events-none whitespace-nowrap">
            NEXUS
          </div>
        </section>
      )}

      {/* Stats Section */}
      {!searchQuery && (
        <section className="bg-black py-16 sm:py-24 px-6 border-b border-white/5">
          <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-y-12 md:gap-0">
            <div className="text-center md:border-r border-white/10 px-4">
              <h3 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#C5A059] mb-2 sm:mb-4">
                <AnimatedCounter end={50000} suffix="+" />
              </h3>
              <p className="text-[9px] sm:text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-bold">Products Tracked</p>
            </div>
            <div className="text-center md:border-r border-white/10 px-4">
              <h3 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#C5A059] mb-2 sm:mb-4">
                <AnimatedCounter end={4} />
              </h3>
              <p className="text-[9px] sm:text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-bold">Platforms</p>
            </div>
            <div className="text-center md:border-r border-white/10 px-4">
              <h3 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#C5A059] mb-2 sm:mb-4">
                <AnimatedCounter end={25} suffix="%" />
              </h3>
              <p className="text-[9px] sm:text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-bold">Avg. Savings %</p>
            </div>
            <div className="text-center px-4">
              <h3 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#C5A059] mb-2 sm:mb-4">
                <AnimatedCounter end={120000} suffix="+" locale="en-IN" />
              </h3>
              <p className="text-[9px] sm:text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-bold">Happy Shoppers</p>
            </div>
          </div>
        </section>
      )}

      {/* The Process Section */}
      {!searchQuery && (
        <section className="py-16 sm:py-24 bg-white px-6">
          <div className="max-w-7xl mx-auto text-center mb-12 sm:mb-16">
            <p className="text-[10px] uppercase tracking-[0.4em] text-[#C5A059] font-bold mb-4">The Process</p>
            <h2 className="text-3xl sm:text-5xl font-serif text-zinc-900">Three steps to the best deal</h2>
          </div>

          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 border border-zinc-100 rounded-2xl overflow-hidden shadow-sm bg-[#FAFAFA]/50">
            <div className="p-8 sm:p-12 border-b md:border-b-0 md:border-r border-zinc-100 flex flex-col items-start text-left">
              <span className="text-5xl sm:text-7xl font-serif text-zinc-100 mb-6 sm:mb-8 block">01</span>
              <h3 className="text-xl sm:text-2xl font-serif mb-4 sm:mb-6 text-zinc-900">Search</h3>
              <p className="text-zinc-500 text-sm leading-relaxed">
                Type any fashion item — kurta, sneakers, jeans — and we find it across all major platforms instantly.
              </p>
            </div>
            <div className="p-8 sm:p-12 border-b md:border-b-0 md:border-r border-zinc-100 flex flex-col items-start text-left">
              <span className="text-5xl sm:text-7xl font-serif text-zinc-100 mb-6 sm:mb-8 block">02</span>
              <h3 className="text-xl sm:text-2xl font-serif mb-4 sm:mb-6 text-zinc-900">Compare</h3>
              <p className="text-zinc-500 text-sm leading-relaxed">
                See side-by-side price comparison from Myntra, Ajio, Flipkart and Amazon with ratings & offers.
              </p>
            </div>
            <div className="p-8 sm:p-12 flex flex-col items-start text-left">
              <span className="text-5xl sm:text-7xl font-serif text-zinc-100 mb-6 sm:mb-8 block">03</span>
              <h3 className="text-xl sm:text-2xl font-serif mb-4 sm:mb-6 text-zinc-900">Shop</h3>
              <p className="text-zinc-500 text-sm leading-relaxed">
                Click the best price and go directly to the platform to complete your purchase. Simple.
              </p>
            </div>
          </div>
        </section>
      )}

      {/* Final CTA Section */}
      {!searchQuery && (
        <section className="bg-black py-16 sm:py-24 px-6">
          <div className="max-w-7xl mx-auto bg-zinc-900/50 rounded-[32px] sm:rounded-[40px] p-8 md:p-20 border border-white/5 flex flex-col lg:flex-row items-center justify-between gap-12 lg:gap-16">
            <div className="max-w-xl text-center lg:text-left">
              <span className="text-[10px] uppercase tracking-[0.4em] text-zinc-500 font-bold mb-6 block">Start Comparing</span>
              <h2 className="text-4xl sm:text-5xl md:text-6xl font-serif text-white mb-8 leading-tight">Never overpay for fashion again.</h2>
              <p className="text-zinc-400 text-base sm:text-lg mb-10 sm:mb-12 leading-relaxed">
                Join 1,20,000+ smart shoppers who save an average of ₹800 per purchase with NEXUS.
              </p>
              <div className="flex flex-col sm:flex-row items-center gap-6 sm:gap-8 justify-center lg:justify-start">
                <Link to="/signup" className="w-full sm:w-auto bg-white text-black px-10 py-4 rounded-xl font-bold text-sm hover:bg-zinc-200 transition-all text-center">
                  Create Free Account
                </Link>
                <Link to="/compare" className="text-white text-sm font-bold hover:translate-x-2 transition-transform flex items-center gap-2">
                  Compare Now <span className="text-xl">→</span>
                </Link>
              </div>
            </div>

            {/* Comparison Card Mockup */}
            <div className="w-full max-w-md bg-zinc-900 border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl">
              <h4 className="text-white font-serif text-xl mb-8">Levi's 511 Slim Jeans</h4>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/5">
                  <span className="text-zinc-400 text-sm">Myntra</span>
                  <span className="text-white font-bold">₹2,999</span>
                </div>
                <div className="flex items-center justify-between p-4 bg-[#C5A059]/10 rounded-xl border border-[#C5A059]/30">
                  <div className="flex items-center gap-3">
                    <span className="text-[#C5A059] text-sm font-bold">Ajio</span>
                    <span className="bg-[#C5A059] text-black text-[8px] font-bold px-2 py-0.5 rounded uppercase">Best</span>
                  </div>
                  <span className="text-[#C5A059] font-bold">₹2,499</span>
                </div>
                <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/5">
                  <span className="text-zinc-400 text-sm">Flipkart</span>
                  <span className="text-white font-bold">₹3,199</span>
                </div>
                <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/5">
                  <span className="text-zinc-400 text-sm">Amazon</span>
                  <span className="text-white font-bold">₹2,799</span>
                </div>
              </div>
              <div className="mt-8 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-center">
                <p className="text-emerald-400 text-sm font-medium">You save ₹700 with NEXUS</p>
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};

export default Home;
